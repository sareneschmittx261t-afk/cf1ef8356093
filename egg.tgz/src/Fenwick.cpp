// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Query fenwick sums"); }
int main(){
  announce();
  return lionss_run_workload("Fenwick");
}
