// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Return from machine trap"); }
int main(){
  announce();
  return lionss_run_workload("riscv-mret");
}
