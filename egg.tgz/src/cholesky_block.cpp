// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Block Cholesky factorize\n", stdout);
  return lionss_run_workload("cholesky_block");
}
