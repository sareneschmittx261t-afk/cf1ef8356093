// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack decal atlas\n", stdout);
  return lionss_run_workload("decal-atlas");
}
